package kr.or.ddit.vo;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.Data;

//UserDetails를 상속받아 인증 객체로 사용
@Data
public class UsersVO implements UserDetails {
	private int id;
	private String email;
	private String password;
	private Date createdAt;
	private Date updatedAt;
	
	//권한 반환
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return List.of(new SimpleGrantedAuthority("user"));
	}
	
	//사용자의 id를 반환(고유한 값)
	@Override
	public String getUsername() {
		return email;
	}
	
	//사용자의 패스워드 반환
	@Override
	public String getPassword() {
		return password;
	}
	
	//계정 만료 여부 반환
	@Override
	public boolean isAccountNonExpired() {
		//만료되었는지 확인하는 로직
		return true; //true -> 만료되지 않았음
	}
	
	//계정 잠금 여부 반환
	@Override
	public boolean isAccountNonLocked() {
		//계정 잠금되었는지 확인하는 로직
		return true; //true -> 잠금되지 않았음
	}
	
	//패스워드의 만료 여부 반환
	@Override
	public boolean isCredentialsNonExpired() {
		//패스워드가 만료되었는지 확인하는 로직
		return true; //true -> 만료되지 않았음
	}
	
	//계정 사용 가능 여부 반환
	@Override
	public boolean isEnabled() {
		//계정의 사용 가능한지 확인하는 로직
		return true; //true -> 사용 가능
	}
}
